package com.connecthub.modules.features.post.service;

import com.connecthub.common.dto.response.CursorResponse;
import com.connecthub.common.util.AppUtil;
import com.connecthub.modules.features.post.dto.response.MentionResponse;
import com.connecthub.modules.features.post.dto.response.PostResponse;
import com.connecthub.modules.features.post.entity.Mention;
import com.connecthub.modules.features.post.exception.PostNotFoundException;
import com.connecthub.modules.features.post.mapper.PostMapper;
import com.connecthub.modules.features.post.repository.MentionRepository;
import com.connecthub.modules.features.post.repository.PostRepository;
import com.connecthub.modules.features.user.dto.response.UserSummaryResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Limit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class MentionService {

    private final MentionRepository mentionRepository;
    private final PostRepository postRepository;
    private final PostMapper postMapper;

    @Transactional(readOnly = true)
    public List<MentionResponse> getMentionsByPost(UUID postId) {
        if (!postRepository.existsById(postId)) {
            throw new PostNotFoundException();
        }
        return mentionRepository.findByPostIdWithUser(postId)
                .stream()
                .map(this::toMentionResponse)
                .toList();
    }
    @Transactional(readOnly = true)
    public CursorResponse<PostResponse> getMyMentions(UUID cursor, int size) {
        UUID userId = AppUtil.userIdFormAuthentication();
        int limit = size > 0 ? size : 20;

        List<Mention> mentions = new ArrayList<>(
                mentionRepository.findPostsMentioningUser(userId, cursor, Limit.of(limit + 1))
        );

        return AppUtil.buildCursorResponse(
                mentions,
                limit,
                Mention::getId,
                m -> postMapper.mapToResponse(m.getPost())
        );
    }

    @Transactional(readOnly = true)
    public long countMyMentions() {
        UUID userId = AppUtil.userIdFormAuthentication();
        return mentionRepository.countByUserId(userId);
    }
    private MentionResponse toMentionResponse(Mention mention) {
        var user = mention.getUser();
        return MentionResponse.builder()
                .id(mention.getId())
                .createdAt(mention.getCreatedAt())
                .user(UserSummaryResponse.builder()
                        .id(user.getId())
                        .username(user.getUsername())
                        .fullName(user.getFullName())
                        .avatarUrl(user.getAvatarUrl())
                        .build())
                .build();
    }
}