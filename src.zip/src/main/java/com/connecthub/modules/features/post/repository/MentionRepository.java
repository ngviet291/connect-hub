package com.connecthub.modules.features.post.repository;

import com.connecthub.modules.features.post.entity.Mention;
import org.springframework.data.domain.Limit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface MentionRepository extends JpaRepository<Mention, UUID> {
    // GET /posts/{postId}/mentions─────────────────────────────────────────────
    // Lấy danh sách user được mention trong bài đăng (dùng khi get post details).
    @Query("""
        SELECT m FROM Mention m
        JOIN FETCH m.user
        WHERE m.post.id = :postId
        ORDER BY m.createdAt ASC
    """)
    List<Mention> findByPostIdWithUser(@Param("postId") UUID postId);

    //GET /users/me/mentions
    // Lấy danh sách bài đăng đang mention user (dùng khi get mentions feed).
    @Query("""
        SELECT m FROM Mention m
        JOIN FETCH m.post p
        JOIN FETCH p.user
        LEFT JOIN FETCH p.media
        WHERE m.user.id = :userId
        AND p.isDeleted = false
        AND p.visibility = 'PUBLIC'
        AND (:cursor IS NULL OR m.id < :cursor)
        ORDER BY m.id DESC
    """)
    List<Mention> findPostsMentioningUser(@Param("userId") UUID userId,
                                          @Param("cursor") UUID cursor,
                                          Limit limit);

    /// Count số bài đăng đang mention user (hiển thị badge thông báo).
    long countByUserId(UUID userId);
    //Kiểm tra user đã được mention trong bài đăng chưa (dùng khi tạo mention).
    boolean existsByPostIdAndUserId(UUID postId, UUID userId);
}