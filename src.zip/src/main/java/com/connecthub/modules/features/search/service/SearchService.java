package com.connecthub.modules.features.search.service;

import com.connecthub.common.dto.response.CursorResponse;
import com.connecthub.common.util.AppUtil;
import com.connecthub.modules.features.post.dto.response.HashtagResponse;
import com.connecthub.modules.features.post.dto.response.PostResponse;
import com.connecthub.modules.features.post.entity.Hashtag;
import com.connecthub.modules.features.post.entity.Post;
import com.connecthub.modules.features.post.mapper.PostMapper;
import com.connecthub.modules.features.post.repository.HashtagRepository;
import com.connecthub.modules.features.post.repository.PostRepository;
import com.connecthub.modules.features.user.dto.response.UserSummaryResponse;
import com.connecthub.modules.features.user.entity.User;
import com.connecthub.modules.features.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Limit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SearchService {

    private static final int DEFAULT_SIZE = 20;

    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final HashtagRepository hashtagRepository;
    private final PostMapper postMapper;

    //Search users, posts, and hashtags with cursor-based pagination
    @Transactional(readOnly = true)
    public CursorResponse<UserSummaryResponse> searchUsers(String keyword, UUID cursor, int size) {
        int limit = size > 0 ? size : DEFAULT_SIZE;
        List<User> users = new ArrayList<>(
                userRepository.searchByKeyword(keyword.trim(), cursor, Limit.of(limit + 1))
        );
        return AppUtil.buildCursorResponse(users, limit, User::getId, this::toUserSummary);
    }

    //Search posts with cursor-based pagination
    @Transactional(readOnly = true)
    public CursorResponse<PostResponse> searchPosts(String keyword, UUID cursor, int size) {
        int limit = size > 0 ? size : DEFAULT_SIZE;
        List<Post> posts = new ArrayList<>(
                postRepository.searchByKeyword(keyword.trim(), cursor, Limit.of(limit + 1))
        );
        return AppUtil.buildCursorResponse(posts, limit, Post::getId, postMapper::mapToResponse);
    }
    //Search hashtags with cursor-based pagination
    @Transactional(readOnly = true)
    public CursorResponse<HashtagResponse> searchHashtags(String keyword, UUID cursor, int size) {
        int limit = size > 0 ? size : DEFAULT_SIZE;
        List<Hashtag> hashtags = new ArrayList<>(
                hashtagRepository.searchByName(keyword.trim(), cursor, Limit.of(limit + 1))
        );
        return AppUtil.buildCursorResponse(hashtags, limit, Hashtag::getId, this::toHashtagResponse);
    }
    //Get trending hashtags with a limit on the number of results
    @Transactional(readOnly = true)
    public List<HashtagResponse> getTrendingHashtags(int size) {
        int limit = size > 0 ? Math.min(size, 50) : 10;
        return hashtagRepository.findTrending(Limit.of(limit))
                .stream()
                .map(this::toHashtagResponse)
                .toList();
    }
    //Get trending posts with a limit on the number of results
    private UserSummaryResponse toUserSummary(User user) {
        return UserSummaryResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .fullName(user.getFullName())
                .avatarUrl(user.getAvatarUrl())
                .build();
    }
    //Convert a Hashtag entity to a HashtagResponse DTO
    private HashtagResponse toHashtagResponse(Hashtag hashtag) {
        return HashtagResponse.builder()
                .id(hashtag.getId())
                .name(hashtag.getName())
                .postCount(hashtag.getPostHashtags() != null
                        ? hashtag.getPostHashtags().size() : 0)
                .build();
    }
}