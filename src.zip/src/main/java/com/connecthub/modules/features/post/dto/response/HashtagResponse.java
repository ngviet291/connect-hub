package com.connecthub.modules.features.post.dto.response;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HashtagResponse {

    private UUID id;
    private String name;
    private int postCount;
}