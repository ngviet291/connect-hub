package com.connecthub.modules.features.search.controller;

import com.connecthub.common.dto.response.ApiResponse;
import com.connecthub.common.dto.response.CursorResponse;
import com.connecthub.modules.features.post.dto.response.HashtagResponse;
import com.connecthub.modules.features.post.dto.response.PostResponse;
import com.connecthub.modules.features.search.service.SearchService;
import com.connecthub.modules.features.user.dto.response.UserSummaryResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/v1/search")
@RequiredArgsConstructor
public class SearchController {

    private final SearchService searchService;

    // GET /v1/search/users?keyword=java&cursor=&limit=20
    // Tìm kiếm người dùng theo từ khoá.
    @GetMapping("/users")
    public ApiResponse<CursorResponse<UserSummaryResponse>> searchUsers(
            @RequestParam String keyword,
            @RequestParam(required = false) UUID cursor,
            @RequestParam(defaultValue = "20") int limit) {
        return ApiResponse.<CursorResponse<UserSummaryResponse>>builder()
                .code(2100)
                .message("Users found")
                .data(searchService.searchUsers(keyword, cursor, limit))
                .build();
    }

   // GET /v1/search/posts?keyword=java&cursor=&limit=20
    // Tìm kiếm bài đăng theo từ khoá.
    @GetMapping("/posts")
    public ApiResponse<CursorResponse<PostResponse>> searchPosts(
            @RequestParam String keyword,
            @RequestParam(required = false) UUID cursor,
            @RequestParam(defaultValue = "20") int limit) {
        return ApiResponse.<CursorResponse<PostResponse>>builder()
                .code(2101)
                .message("Posts found")
                .data(searchService.searchPosts(keyword, cursor, limit))
                .build();
    }
    // GET /v1/search/hashtags?keyword=java&cursor=&limit=20
    // Tìm kiếm hashtag theo từ khoá.
    @GetMapping("/hashtags")
    public ApiResponse<CursorResponse<HashtagResponse>> searchHashtags(
            @RequestParam String keyword,
            @RequestParam(required = false) UUID cursor,
            @RequestParam(defaultValue = "20") int limit) {
        return ApiResponse.<CursorResponse<HashtagResponse>>builder()
                .code(2102)
                .message("Hashtags found")
                .data(searchService.searchHashtags(keyword, cursor, limit))
                .build();
    }
    // GET /v1/search/hashtags/trending?limit=10
    // Lấy danh sách hashtag phổ biến nhất hiện tại, sắp xếp theo số lượng bài đăng sử dụng hashtag.
    @GetMapping("/hashtags/trending")
    public ApiResponse<List<HashtagResponse>> getTrendingHashtags(
            @RequestParam(defaultValue = "10") int limit) {
        return ApiResponse.<List<HashtagResponse>>builder()
                .code(2103)
                .message("Trending hashtags retrieved")
                .data(searchService.getTrendingHashtags(limit))
                .build();
    }
}